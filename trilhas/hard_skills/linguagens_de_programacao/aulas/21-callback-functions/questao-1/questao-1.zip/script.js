function callback(texto) {
  console.log(texto)
}
